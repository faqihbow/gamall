/* Logika website Rotan Pak Ridwan */
const LOCALES = { id: "id-ID", en: "en-US", zh: "zh-CN" };
const WA_NUMBER = "6281234567890";
const PRODUCTION_DAYS = 14;
const PROCESS_DAYS = 2;

const state = { lang: "id", cat: "all", query: "", faq: "", order: [] };
const $ = (sel) => document.querySelector(sel);
const t = (key) => T[state.lang][key] || key;
const money = (n) => new Intl.NumberFormat(LOCALES[state.lang], { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* abaikan */ } }
};

function showToast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => el.classList.remove("show"), 1800);
}

function stockBadge(variant) {
  return variant.stock > 0
    ? `<span class="badge bg-success">${t("ready")} · ${variant.stock} ${t("stock")}</span>`
    : `<span class="badge bg-warning text-dark">${t("preorder")} (+${PRODUCTION_DAYS} ${t("days")})</span>`;
}

/* ---------- Bahasa & tema ---------- */
function applyLanguage() {
  document.documentElement.lang = state.lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  document.querySelectorAll(".lang-btn").forEach((b) => b.classList.toggle("active", b.dataset.lang === state.lang));
  renderCategories();
  renderProducts();
  renderDestinations();
  renderFaq();
  renderOrder();
}

function setTheme(theme) {
  document.documentElement.setAttribute("data-bs-theme", theme);
  $("#themeBtn").innerHTML = theme === "dark" ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
  store.set("theme", theme);
}

/* ---------- Produk ---------- */
function renderCategories() {
  const cats = ["all", "furniture", "craft", "material"];
  $("#catButtons").innerHTML = cats.map((c) =>
    `<button class="btn btn-outline-secondary btn-cat ${state.cat === c ? "active" : ""}" data-cat="${c}">${t(c)}</button>`).join("");
}

function renderProducts() {
  const q = state.query.toLowerCase();
  const list = PRODUCTS.filter((p) => (state.cat === "all" || p.cat === state.cat) && p.name[state.lang].toLowerCase().includes(q));
  $("#productGrid").innerHTML = list.map((p) => `
    <div class="col-sm-6 col-lg-3">
      <div class="card product-card h-100" data-pid="${p.id}">
        <img src="${p.img}" class="card-img-top" alt="${p.name[state.lang]}">
        <div class="card-body d-flex flex-column">
          <h3 class="h6 fw-bold">${p.name[state.lang]}</h3>
          <p class="small text-body-secondary">${p.desc[state.lang]}</p>
          <label class="small">${t("variant")}</label>
          <select class="form-select form-select-sm mb-2 variant-select">
            ${p.variants.map((v, i) => `<option value="${i}">${v.name[state.lang]}</option>`).join("")}
          </select>
          <div class="mb-1 fw-bold text-success price-label">${money(p.variants[0].price)}</div>
          <div class="mb-2 badge-box">${stockBadge(p.variants[0])}</div>
          <div class="input-group input-group-sm mt-auto">
            <button class="btn btn-outline-secondary" data-act="minus">−</button>
            <input type="number" class="form-control text-center qty-input" value="1" min="1" max="999">
            <button class="btn btn-outline-secondary" data-act="plus">+</button>
            <button class="btn btn-warning" data-act="add"><i class="bi bi-cart-plus"></i> ${t("add")}</button>
          </div>
        </div>
      </div>
    </div>`).join("");
}

/* ---------- Pesanan ---------- */
function renderDestinations() {
  const current = $("#dest").value;
  $("#dest").innerHTML = DESTINATIONS.map((d) => `<option value="${d.id}">${d.name[state.lang]}</option>`).join("");
  if (current) $("#dest").value = current;
}

function calculateOrder() {
  const dest = DESTINATIONS.find((d) => d.id === $("#dest").value) || DESTINATIONS[0];
  const [rate, minDays, maxDays] = dest[$("#method").value];
  let subtotal = 0, weight = 0, needsProduction = false;
  state.order.forEach((item) => {
    const p = PRODUCTS.find((x) => x.id === item.pid);
    const v = p.variants[item.vi];
    subtotal += v.price * item.qty;
    weight += p.weight * item.qty;
    if (v.stock < item.qty) needsProduction = true;
  });
  const shipping = state.order.length ? dest.base + Math.ceil(weight) * rate : 0;
  const wait = (needsProduction ? PRODUCTION_DAYS : 0) + PROCESS_DAYS;
  return { dest, subtotal, weight, shipping, total: subtotal + shipping, min: wait + minDays, max: wait + maxDays };
}

function formatDate(offset) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toLocaleDateString(LOCALES[state.lang], { day: "numeric", month: "short", year: "numeric" });
}

function renderOrder() {
  const box = $("#orderList");
  if (!state.order.length) {
    box.innerHTML = `<p class="text-body-secondary text-center my-4"><i class="bi bi-bag fs-1 d-block"></i>${t("empty")}</p>`;
  } else {
    box.innerHTML = state.order.map((item, idx) => {
      const p = PRODUCTS.find((x) => x.id === item.pid);
      const v = p.variants[item.vi];
      return `<div class="d-flex align-items-center gap-2 border-bottom py-2">
        <img src="${p.img}" width="56" height="42" class="rounded" alt="">
        <div class="flex-grow-1"><b>${p.name[state.lang]}</b><br><small>${v.name[state.lang]} · ${money(v.price)}</small><br>${stockBadge(v)}</div>
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-secondary" data-oact="dec" data-idx="${idx}">−</button>
          <span class="btn btn-light disabled">${item.qty}</span>
          <button class="btn btn-outline-secondary" data-oact="inc" data-idx="${idx}">+</button>
        </div>
        <b class="text-end" style="min-width:90px">${money(v.price * item.qty)}</b>
        <button class="btn btn-sm btn-outline-danger" data-oact="del" data-idx="${idx}" aria-label="Delete"><i class="bi bi-trash"></i></button>
      </div>`;
    }).join("");
  }
  const r = calculateOrder();
  $("#subtotal").textContent = money(r.subtotal);
  $("#shipCost").textContent = money(r.shipping);
  $("#grandTotal").textContent = money(r.total);
  $("#etaBox").innerHTML = state.order.length
    ? `<i class="bi bi-truck"></i> <b>${t("eta")}:</b> ${r.min}–${r.max} ${t("days")}<br><small>${formatDate(r.min)} ${t("to")} ${formatDate(r.max)} · ${t("weight")}: ${r.weight} kg</small>`
    : `<i class="bi bi-truck"></i> ${t("eta")}: -`;
  updateWhatsapp(r);
}

function updateWhatsapp(r) {
  const btn = $("#waBtn");
  if (!state.order.length) { btn.classList.add("disabled"); btn.removeAttribute("href"); return; }
  const lines = state.order.map((item) => {
    const p = PRODUCTS.find((x) => x.id === item.pid);
    return `- ${p.name[state.lang]} (${p.variants[item.vi].name[state.lang]}) x${item.qty}`;
  });
  const text = `${t("hello")}\n${lines.join("\n")}\n${t("dst")}: ${r.dest.name[state.lang]}\n${t("total")}: ${money(r.total)}\n${t("eta")}: ${r.min}-${r.max} ${t("days")}`;
  btn.href = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`;
  btn.classList.remove("disabled");
}

function addToOrder(pid, vi, qty) {
  const found = state.order.find((i) => i.pid === pid && i.vi === vi);
  if (found) found.qty += qty; else state.order.push({ pid, vi, qty });
  renderOrder();
  showToast(t("added"));
}

/* ---------- FAQ ---------- */
function renderFaq() {
  const q = state.faq.toLowerCase();
  const list = FAQS.filter((f) => (f.q[state.lang] + f.a[state.lang]).toLowerCase().includes(q));
  $("#faqList").innerHTML = list.length ? list.map((f, i) => `
    <div class="accordion-item">
      <h3 class="accordion-header"><button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#faq${i}">${f.q[state.lang]}</button></h3>
      <div id="faq${i}" class="accordion-collapse collapse" data-bs-parent="#faqList"><div class="accordion-body">${f.a[state.lang]}</div></div>
    </div>`).join("") : `<p class="text-body-secondary">${t("nofaq")}</p>`;
}

/* ---------- Event ---------- */
function bindEvents() {
  document.querySelectorAll(".lang-btn").forEach((b) => b.addEventListener("click", () => {
    state.lang = b.dataset.lang; store.set("lang", state.lang); applyLanguage();
  }));
  $("#themeBtn").addEventListener("click", () => {
    setTheme(document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark");
  });
  $("#catButtons").addEventListener("click", (e) => {
    const b = e.target.closest("[data-cat]"); if (!b) return;
    state.cat = b.dataset.cat; renderCategories(); renderProducts();
  });
  $("#searchProduct").addEventListener("input", (e) => { state.query = e.target.value; renderProducts(); });
  $("#faqSearch").addEventListener("input", (e) => { state.faq = e.target.value; renderFaq(); });

  const grid = $("#productGrid");
  grid.addEventListener("change", (e) => {
    if (!e.target.classList.contains("variant-select")) return;
    const card = e.target.closest(".product-card");
    const v = PRODUCTS.find((p) => p.id === card.dataset.pid).variants[e.target.value];
    card.querySelector(".price-label").textContent = money(v.price);
    card.querySelector(".badge-box").innerHTML = stockBadge(v);
  });
  grid.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-act]"); if (!btn) return;
    const card = btn.closest(".product-card");
    const input = card.querySelector(".qty-input");
    const qty = Math.max(1, parseInt(input.value, 10) || 1);
    if (btn.dataset.act === "plus") input.value = Math.min(999, qty + 1);
    if (btn.dataset.act === "minus") input.value = Math.max(1, qty - 1);
    if (btn.dataset.act === "add") addToOrder(card.dataset.pid, Number(card.querySelector(".variant-select").value), qty);
  });
  $("#orderList").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-oact]"); if (!btn) return;
    const idx = Number(btn.dataset.idx);
    if (btn.dataset.oact === "inc") state.order[idx].qty++;
    if (btn.dataset.oact === "dec") state.order[idx].qty = Math.max(1, state.order[idx].qty - 1);
    if (btn.dataset.oact === "del") { state.order.splice(idx, 1); showToast(t("removed")); }
    renderOrder();
  });
  $("#dest").addEventListener("change", renderOrder);
  $("#method").addEventListener("change", renderOrder);

  const toTop = $("#toTop");
  window.addEventListener("scroll", () => { toTop.style.display = window.scrollY > 400 ? "block" : "none"; highlightNav(); });
  toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function highlightNav() {
  let current = "";
  document.querySelectorAll("section[id]").forEach((s) => { if (window.scrollY + 120 >= s.offsetTop) current = s.id; });
  document.querySelectorAll(".nav-link").forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + current));
}

function animateCounters() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (!en.isIntersecting) return;
      const el = en.target, to = Number(el.dataset.to);
      let n = 0;
      const timer = setInterval(() => { n += Math.ceil(to / 40); if (n >= to) { n = to; clearInterval(timer); } el.textContent = n + "+"; }, 30);
      observer.unobserve(el);
    });
  });
  document.querySelectorAll(".counter").forEach((c) => observer.observe(c));
}

document.addEventListener("DOMContentLoaded", () => {
  const savedLang = store.get("lang");
  if (savedLang && T[savedLang]) state.lang = savedLang;
  setTheme(store.get("theme") === "dark" ? "dark" : "light");
  bindEvents();
  applyLanguage();
  animateCounters();
});
