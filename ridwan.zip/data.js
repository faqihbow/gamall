/* Data bisnis: produk, varian, tarif ongkir, FAQ, dan terjemahan */
const PRODUCTS = [
  { id: "kursi", cat: "furniture", img: "assets/kursi.svg", weight: 6,
    name: { id: "Kursi Rotan Anyaman", en: "Woven Rattan Chair", zh: "编织藤椅" },
    desc: { id: "Kursi santai anyaman tangan, kuat dan ringan.", en: "Hand-woven lounge chair, strong yet light.", zh: "手工编织休闲椅，结实轻巧。" },
    variants: [
      { name: { id: "Natural", en: "Natural", zh: "原色" }, price: 450000, stock: 120 },
      { name: { id: "Hitam", en: "Black", zh: "黑色" }, price: 480000, stock: 35 },
      { name: { id: "Putih", en: "White", zh: "白色" }, price: 480000, stock: 0 }
    ] },
  { id: "meja", cat: "furniture", img: "assets/meja.svg", weight: 12,
    name: { id: "Meja Rotan Bundar", en: "Round Rattan Table", zh: "圆形藤桌" },
    desc: { id: "Meja teras bundar dengan rangka rotan pilihan.", en: "Round patio table with a select rattan frame.", zh: "精选藤架圆形露台桌。" },
    variants: [
      { name: { id: "Diameter 60 cm", en: "60 cm diameter", zh: "直径60厘米" }, price: 650000, stock: 40 },
      { name: { id: "Diameter 80 cm", en: "80 cm diameter", zh: "直径80厘米" }, price: 850000, stock: 12 }
    ] },
  { id: "keranjang", cat: "craft", img: "assets/keranjang.svg", weight: 1.5,
    name: { id: "Keranjang Rotan", en: "Rattan Basket", zh: "藤编篮" },
    desc: { id: "Keranjang serbaguna untuk dekorasi dan penyimpanan.", en: "Versatile basket for decor and storage.", zh: "装饰与收纳两用藤篮。" },
    variants: [
      { name: { id: "Kecil (S)", en: "Small (S)", zh: "小号(S)" }, price: 75000, stock: 300 },
      { name: { id: "Sedang (M)", en: "Medium (M)", zh: "中号(M)" }, price: 120000, stock: 180 },
      { name: { id: "Besar (L)", en: "Large (L)", zh: "大号(L)" }, price: 180000, stock: 0 }
    ] },
  { id: "bahan", cat: "material", img: "assets/rotan.svg", weight: 10,
    name: { id: "Rotan Mentah (per ikat 10 kg)", en: "Raw Rattan (10 kg bundle)", zh: "原藤(每捆10公斤)" },
    desc: { id: "Batang rotan kering siap olah untuk pengrajin.", en: "Dried rattan poles ready for crafters.", zh: "供工匠使用的干燥藤条。" },
    variants: [
      { name: { id: "Rotan Poles 8-12 mm", en: "Poles 8-12 mm", zh: "藤条8-12毫米" }, price: 350000, stock: 500 },
      { name: { id: "Kulit Rotan (Peel)", en: "Rattan Peel", zh: "藤皮" }, price: 280000, stock: 90 }
    ] }
];

/* Tarif: base = biaya dasar (Rp), rate = Rp per kg, [min, max] hari */
const DESTINATIONS = [
  { id: "jkt", name: { id: "Jakarta (Domestik)", en: "Jakarta (Domestic)", zh: "雅加达(国内)" }, base: 50000, sea: [9000, 2, 4], air: [25000, 1, 2] },
  { id: "sg", name: { id: "Singapura", en: "Singapore", zh: "新加坡" }, base: 400000, sea: [45000, 7, 10], air: [120000, 3, 5] },
  { id: "my", name: { id: "Malaysia", en: "Malaysia", zh: "马来西亚" }, base: 350000, sea: [40000, 6, 9], air: [110000, 3, 5] },
  { id: "jp", name: { id: "Jepang", en: "Japan", zh: "日本" }, base: 600000, sea: [60000, 12, 16], air: [150000, 4, 6] },
  { id: "nl", name: { id: "Belanda", en: "Netherlands", zh: "荷兰" }, base: 900000, sea: [75000, 28, 35], air: [190000, 5, 8] },
  { id: "us", name: { id: "Amerika Serikat", en: "United States", zh: "美国" }, base: 1000000, sea: [85000, 30, 40], air: [210000, 6, 9] }
];

const FAQS = [
  { q: { id: "Apakah produk selalu ready?", en: "Are products always in stock?", zh: "产品都有现货吗？" },
    a: { id: "Stok tiap varian tertera di kartu produk. Jika stok kurang, status berubah menjadi pre-order dengan tambahan produksi 14 hari.", en: "Stock for each variant is shown on the product card. If stock is short, it becomes pre-order with 14 extra production days.", zh: "每个款式的库存显示在产品卡片上。库存不足时转为预订，需额外14天生产。" } },
  { q: { id: "Bagaimana cara menghitung total harga?", en: "How is the total price calculated?", zh: "总价如何计算？" },
    a: { id: "Pilih varian dan jumlah, tekan Tambah. Total (harga barang + ongkir) dihitung otomatis di bagian Pesanan.", en: "Choose a variant and quantity, then press Add. The total (goods + shipping) is calculated automatically in the Order section.", zh: "选择款式和数量后点击添加，订单区会自动计算总价(货款+运费)。" } },
  { q: { id: "Berapa biaya pengiriman?", en: "How much is shipping?", zh: "运费是多少？" },
    a: { id: "Ongkir = biaya dasar + tarif per kg berdasarkan berat total, tujuan, dan metode (laut atau udara).", en: "Shipping = base fee + per-kg rate based on total weight, destination, and method (sea or air).", zh: "运费 = 基本费 + 按总重量、目的地和方式(海运/空运)计算的每公斤费用。" } },
  { q: { id: "Berapa lama barang sampai?", en: "How long until delivery?", zh: "多久能送达？" },
    a: { id: "Proses 2 hari (ready) ditambah waktu kirim. Laut lebih lama namun hemat, udara lebih cepat.", en: "2 days processing (in stock) plus transit time. Sea is slower but cheaper, air is faster.", zh: "现货处理2天，加运输时间。海运较慢但便宜，空运更快。" } },
  { q: { id: "Bagaimana cara memesan?", en: "How do I place an order?", zh: "如何下单？" },
    a: { id: "Susun pesanan lalu tekan tombol WhatsApp. Pesan berisi rincian otomatis terkirim ke Pak Ridwan.", en: "Build your order and press the WhatsApp button. A message with details is sent to Pak Ridwan automatically.", zh: "整理订单后点击WhatsApp按钮，详情将自动发送给Ridwan先生。" } }
];

const T = {
  id: { nav_about: "Tentang", nav_products: "Produk", nav_order: "Pesanan", nav_faq: "FAQ",
    hero_title: "Rotan Berkualitas dari Cirebon untuk Dunia", hero_sub: "Furnitur, kerajinan, dan bahan rotan pilihan. Cek stok, harga, ongkir, dan estimasi tiba langsung di sini.",
    cta1: "Lihat Produk", cta2: "Hitung Pesanan", about_title: "Tentang Rotan Pak Ridwan",
    about_text: "Dipimpin Pak Ridwan di Cirebon, kami mengekspor produk rotan buatan pengrajin lokal ke berbagai negara dengan kualitas terjaga dan pengemasan aman.",
    stat1: "Tahun pengalaman", stat2: "Negara tujuan", stat3: "Pengrajin", prod_title: "Produk & Varian", search_ph: "Cari produk...",
    all: "Semua", furniture: "Furnitur", craft: "Kerajinan", material: "Bahan Baku", ready: "Ready", preorder: "Pre-order", stock: "stok",
    add: "Tambah", variant: "Varian", order_title: "Pesanan & Estimasi", empty: "Belum ada item. Tambahkan produk dulu.",
    dest: "Tujuan pengiriman", method: "Metode", sea: "Kapal laut", air: "Pesawat udara", subtotal: "Subtotal", ship: "Ongkir", total: "Total",
    eta: "Estimasi tiba", to: "s.d.", days: "hari", weight: "Berat total", wa: "Pesan via WhatsApp", added: "Ditambahkan ke pesanan", removed: "Item dihapus",
    faq_title: "Pertanyaan yang Sering Diajukan", faq_search: "Cari pertanyaan...", footer: "Eksportir rotan terpercaya sejak 2011", nofaq: "Tidak ada hasil.", hello: "Halo Pak Ridwan, saya ingin memesan:", dst: "Tujuan" },
  en: { nav_about: "About", nav_products: "Products", nav_order: "Order", nav_faq: "FAQ",
    hero_title: "Quality Rattan from Cirebon to the World", hero_sub: "Select rattan furniture, crafts, and materials. Check stock, price, shipping, and arrival estimates right here.",
    cta1: "View Products", cta2: "Calculate Order", about_title: "About Rotan Pak Ridwan",
    about_text: "Led by Pak Ridwan in Cirebon, we export rattan products made by local artisans worldwide, with consistent quality and safe packaging.",
    stat1: "Years of experience", stat2: "Destination countries", stat3: "Artisans", prod_title: "Products & Variants", search_ph: "Search products...",
    all: "All", furniture: "Furniture", craft: "Crafts", material: "Raw Material", ready: "In stock", preorder: "Pre-order", stock: "stock",
    add: "Add", variant: "Variant", order_title: "Order & Estimate", empty: "No items yet. Add a product first.",
    dest: "Shipping destination", method: "Method", sea: "Sea freight", air: "Air freight", subtotal: "Subtotal", ship: "Shipping", total: "Total",
    eta: "Estimated arrival", to: "to", days: "days", weight: "Total weight", wa: "Order via WhatsApp", added: "Added to order", removed: "Item removed",
    faq_title: "Frequently Asked Questions", faq_search: "Search questions...", footer: "Trusted rattan exporter since 2011", nofaq: "No results.", hello: "Hello Pak Ridwan, I would like to order:", dst: "Destination" },
  zh: { nav_about: "关于", nav_products: "产品", nav_order: "订单", nav_faq: "常见问题",
    hero_title: "来自井里汶的优质藤制品，走向世界", hero_sub: "精选藤制家具、工艺品和原料。库存、价格、运费与到货时间一目了然。",
    cta1: "查看产品", cta2: "计算订单", about_title: "关于Ridwan藤业",
    about_text: "在Ridwan先生带领下，我们将本地工匠制作的藤制品出口到世界各地，品质稳定，包装安全。",
    stat1: "年经验", stat2: "出口国家", stat3: "工匠", prod_title: "产品与款式", search_ph: "搜索产品...",
    all: "全部", furniture: "家具", craft: "工艺品", material: "原料", ready: "现货", preorder: "预订", stock: "库存",
    add: "添加", variant: "款式", order_title: "订单与预估", empty: "暂无商品，请先添加。",
    dest: "目的地", method: "运输方式", sea: "海运", air: "空运", subtotal: "小计", ship: "运费", total: "总计",
    eta: "预计到达", to: "至", days: "天", weight: "总重量", wa: "通过WhatsApp下单", added: "已加入订单", removed: "已删除",
    faq_title: "常见问题", faq_search: "搜索问题...", footer: "自2011年的可靠藤制品出口商", nofaq: "没有结果。", hello: "您好Ridwan先生，我想订购：", dst: "目的地" }
};
